/* 
 * File:   Bet.h
 * Author: Anthony Nunez
 *
 * Created on November 9, 2024, 1:49 PM
 */

#ifndef BET_H
#define BET_H

class Bet {
private:
    float bet;
    // Bet amount when starting blackjack
    float payout;
    // Payout multiplier based on difficulty
    float bank;
    // Player's current bank balance
    char difficulty;
    // Current difficulty level

public:
    Bet(float betAmnt = 100, char betDifficulty = 'c');
    // Constructor

    void BankStore(int result, char& repeat);
    // Updates the bank based on the game result

    void setBet(float newBet);
    // Sets a new bet amount

    void setDifficulty(char newDifficulty);
    // Sets a new difficulty level

    float getBet() const;
    // Gets the current bet amount

    char getDifficulty() const;
    // Gets the current difficulty level

    float getPayout() const;
    // Gets the payout multiplier

    float getBank() const;
    // Gets the current bank balance
};

#endif /* BET_H */
