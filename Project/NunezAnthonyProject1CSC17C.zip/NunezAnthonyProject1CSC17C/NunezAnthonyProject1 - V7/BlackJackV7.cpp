/*
 * File:   BlackJack.cpp
 * Author: Anthony Nunez
 
 * Created on November 8, 2024, 7:30 PM
 */

#include <iostream>
#include <cstring>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <list>
#include <stack>
#include <queue>
#include <map>
#include <algorithm>
#include <numeric>
#include <ctime>
#include <random>
#include <limits>

using namespace std;

// Enumerated types for card suits and ranks
enum Suit { Diamonds, Clubs, Hearts, Spades };
enum Rank { Ace = 1, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King };

// Map to associate card ranks with their values
map<Rank, int> cardValues = {
    {Ace, 11}, {Two, 2}, {Three, 3}, {Four, 4}, {Five, 5},
    {Six, 6}, {Seven, 7}, {Eight, 8}, {Nine, 9}, {Ten, 10},
    {Jack, 10}, {Queen, 10}, {King, 10}
};

// Struct representing a card
struct card {
    Suit suit;
    // Suit of the card
    Rank rank;
    // Rank of the card
    int suitNumber = 4;
    // Total number of suits
    int rankNumber = 13;
    // Total number of ranks
};

// Struct representing a deck of cards using a list
struct deck {
    list<card> cards;
    // List of cards in the deck
    int deckSize;
    // Total number of cards in the deck
};

// Bet class handles betting information and player bank
class Bet {
private:
    float bet;
    // Bet amount when starting blackjack
    float payout;
    // Payout multiplier based on difficulty
    float bank;
    // Player's current bank balance
    char difficulty;
    // Current difficulty level

public:
    Bet(float betAmnt = 100, char betDifficulty = 'c');
    // Constructor
    void BankStore(int result, char& repeat);
    // Updates the bank based on the game result
    void setBet(float newBet);
    // Sets a new bet amount
    void setDifficulty(char newDifficulty);
    // Sets a new difficulty level
    float getBet() const;
    // Gets the current bet amount
    char getDifficulty() const;
    // Gets the current difficulty level
    float getPayout() const;
    // Gets the payout multiplier
    //possibly dont need to make last 2 public, but break otherwise
    float getBank() const;
    // Gets the current bank balance
};

// Implementation of Bet class methods

// Constructor for the Bet class
Bet::Bet(float betAmnt, char betDifficulty) {
    bet = betAmnt;
    difficulty = betDifficulty;
    bank = 500;
    if (difficulty == 'c') {
        payout = 1.20f;
    } else if (difficulty == 'n') {
        payout = 1.50f;
    } else if (difficulty == 'v') {
        payout = 1.80f;
    }
}

// Updates the bank based on the game result
void Bet::BankStore(int result, char& repeat) {
    if (result == 1) {
        bank = bank + (bet * payout);
        cout << "\nYou won! Your payout is " << bet * payout << ".\n";
    } else if (result == -1) {
        bank = bank - bet;
        cout << "\nYou lost. You lost your bet of " << bet << ".\n";
    } else {
        cout << "\nIt's a tie. You neither win nor lose money.\n";
    }
    cout << "Your balance is now " << bank << endl;
    if (bank <= 0) {
        cout << "You have run out of money!\n";
        repeat = 'n';
    }
}

// Sets a new bet amount
void Bet::setBet(float newBet) {
    bet = newBet;
}

// Sets a new difficulty level
void Bet::setDifficulty(char newDifficulty) {
    difficulty = newDifficulty;
    if (difficulty == 'c') {
        payout = 1.20f;
    } else if (difficulty == 'n') {
        payout = 1.50f;
    } else if (difficulty == 'v') {
        payout = 1.80f;
    }
}

// Gets the current bet amount
float Bet::getBet() const {
    return bet;
}
// Gets the current difficulty level
char Bet::getDifficulty() const {
    return difficulty;
}
// Gets the payout multiplier
float Bet::getPayout() const {
    return payout;
}
// Gets the current bank balance
float Bet::getBank() const {
    return bank;
}

// BetHistory class tracks the player's betting history
class BetHistory {
private:
    struct BetRecord {
        float amount;
        // The bet amount
        int result;
        // Result of the bet (1: win, -1: loss, 0: tie)
    };
    std::vector<BetRecord> history;
    // Vector to store bet records

public:
    void addBet(float amount, int result);
    // Adds a bet record to the history
    int getTotalGames() const;
    // Gets the total number of games player
    int getWins() const;
    // Gets the total number of wins
    int getLosses() const;
    // Gets the total number of losses
    int getTies() const;
    // Gets the total number of ties
    float getWinRate() const;
    // Gets the win rate
    float getTotalEarnings() const;
    // Gets the total earnings
};

// Implementation of BetHistory methods

// Adds a bet record to the history
void BetHistory::addBet(float amount, int result) {
    history.push_back({amount, result});
}

// Gets the total number of games played
int BetHistory::getTotalGames() const {
    return history.size();
}

// Gets the total number of wins
int BetHistory::getWins() const {
    return std::count_if(history.begin(), history.end(), [](const BetRecord& br) {
        return br.result == 1;
    });
}

// Gets the total number of losses
int BetHistory::getLosses() const {
    return std::count_if(history.begin(), history.end(), [](const BetRecord& br) {
        return br.result == -1;
    });
}

// Gets the total number of ties
int BetHistory::getTies() const {
    return std::count_if(history.begin(), history.end(), [](const BetRecord& br) {
        return br.result == 0;
    });
}

// Gets the win rate
float BetHistory::getWinRate() const {
    int totalGames = getTotalGames();
    if (totalGames == 0) return 0.0f;
    return static_cast<float>(getWins()) / totalGames;
}

// Gets the total earnings
float BetHistory::getTotalEarnings() const {
    float earnings = 0.0f;
    for (const auto& br : history) {
        earnings += br.amount * br.result;
    }
    return earnings;
}

// Function prototypes
void menu(deck& Deck, Bet& Bets, BetHistory& history);
void startUp(deck& cardDeck, char difficulty);
void shuffle(deck& Deck);
void printDeck(deck& Deck);
void printCard(const card& Card);
bool drawCard(deck& Deck, card& drawnCard);
void displayPlayerHand(queue<card> playerHand, int& total);
void displayDealerHand(stack<card> dealerHand, int& total);
void Game(deck& Deck, int& result, Bet& Bets, BetHistory& history);
bool validateYesNo(char& choice);
bool validateMenuChoice(char& choice, const string& validOptions);
bool validateBetAmount(float& betAmount);
bool shouldDealerHit(int dealerTotal, bool dealerHitsOnSoft17);
void displayStatistics(const BetHistory& history);

int main(int argc, char** argv) {
    //could definitely make a more random generator, but i do not have the time
    srand(static_cast<unsigned int>(time(0)));
    // Seed the random number generator

    float betAmount = 100;
    // Initialize bet amount
    char difficulty = 'c';
    // Initialize difficulty level
    Bet Bets(betAmount, difficulty);
    // Initialize Bet object

    BetHistory history;
    // Initialize BetHistory object

    deck cardDeck;
    // Initialize deck object
    startUp(cardDeck, difficulty);
    // Initialize the deck based on difficulty
    shuffle(cardDeck);
    // Shuffle the deck

    menu(cardDeck, Bets, history);
    // Start the game menu
    return 0;
}

// Initializes the deck and assigns all of the values
void startUp(deck& cardDeck, char difficulty) {
    cardDeck.cards.clear();
    // Clear any existing cards in the deck
    card cardId;
    int numDecks = 1;
    // Default to 1 deck

    // Set the number of decks based on difficulty
    switch (difficulty) {
        case 'c':
            numDecks = 1;
            break;
        case 'n':
            numDecks = 2;
            break;
        case 'v':
            numDecks = 8;
            break;
        default:
            numDecks = 1;
            break;
    }

    // Initialize the deck
    for (int d = 0; d < numDecks; ++d) {
        for (int s = 0; s < cardId.suitNumber; s++) {
            // Suit
            for (int r = 1; r <= cardId.rankNumber; r++) {
                // Rank
                cardId.suit = Suit(s);
                cardId.rank = Rank(r);
                cardDeck.cards.push_back(cardId);
            }
        }
    }

    cardDeck.deckSize = numDecks * 52;
    // Update deck size

    cardDeck.cards.sort([](const card& a, const card& b) {
        if (a.suit == b.suit)
            return a.rank < b.rank;
        return a.suit < b.suit;
    });
    // Sort the deck before shuffling
}

// Prints the entire deck (for when things mess up)
void printDeck(deck& Deck) {
    for (const auto& cardId : Deck.cards) {
        printCard(cardId);
    }
}

// Prints a single card
void printCard(const card& Card) {
    string rankName[13] = { "Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight",
                            "Nine", "Ten", "Jack", "Queen", "King" };
    string suitName[4] = { "Diamonds", "Clubs", "Hearts", "Spades" };

    cout << rankName[Card.rank - 1] << " of ";
    cout << suitName[Card.suit] << ", ";
}

// Menu function
void menu(deck& Deck, Bet& Bets, BetHistory& history) {
    char choice;
    char repeat = 'y';

    // Game loop
    do {
        cout << "\nBlackJack: Project 3\n";
        cout << "1. Play Game\n";
        cout << "2. Display rules\n";
        cout << "3. Change bet and difficulty settings\n";
        cout << "4. View betting statistics\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        if (!validateMenuChoice(choice, "12345")) {
            continue;
        }

        switch (choice) {
            case '1': {
                int result = 0;
                Game(Deck, result, Bets, history);
                // Play the game
                Bets.BankStore(result, repeat);
                // Update bank based on result
                if (repeat != 'n') {
                    cout << "Would you like to play again? (y/n): ";
                    if (!validateYesNo(repeat)) {
                        repeat = 'n';
                    }
                    if (repeat == 'y') {
                        if (Deck.cards.size() < 15) {
                            // Reinitialize and shuffle the deck if low on cards
                            startUp(Deck, Bets.getDifficulty());
                            shuffle(Deck);
                        }
                    }
                }
                break;
            }

            case '2':
                cout << "\n--- Game Rules ---\n";
                cout << "The goal of blackjack is to reach a total of 21 with your combined cards.\n";
                cout << "Each card rank is allocated to its respective value with exceptions for face cards and aces.\n";
                cout << "Face cards are worth 10 and aces are worth 11 unless the total is over 21, in which case they become 1.\n";
                cout << "The dealer starts with two cards, one face down until you are done drawing.\n";
                cout << "If the dealer busts by going over 21 or you have a higher value than them under 21, you win.\n";
                break;

            case '3':
                cout << "Your current bet is at " << Bets.getBet() << endl;
                cout << "The balance you start at is 500\n";
                cout << "c: Casual, 1 deck shoe, dealer stands on soft 17, 1.2 payout rate\n";
                cout << "n: Normal, 2 deck shoe, dealer hits on soft 17, 1.5 payout rate\n";
                cout << "v: Vegas, 8 deck shoe, dealer hits on soft 17, 1.8 payout rate\n";
                cout << "Current difficulty is: " << Bets.getDifficulty() << endl;
                cout << "Would you like to change bet? (y/n): ";
                char betChoice;
                if (validateYesNo(betChoice) && betChoice == 'y') {
                    cout << "Enter new bet amount of 100 minimum: ";
                    float betAmount;
                    if (validateBetAmount(betAmount)) {
                        Bets.setBet(betAmount);
                    }
                }

                cout << "Would you like to change difficulty? (y/n): ";
                char diffChoice;
                if (validateYesNo(diffChoice) && diffChoice == 'y') {
                    char difficulty;
                    do {
                        cout << "Select your difficulty \n c: Casual \nn: Normal \nv: Vegas\n";
                        cin >> difficulty;
                        difficulty = tolower(difficulty);
                        if (difficulty != 'c' && difficulty != 'n' && difficulty != 'v') {
                            cout << "Incorrect input, please input either c, n, or v\n";
                        } else {
                            Bets.setDifficulty(difficulty);
                            startUp(Deck, difficulty);
                            // Reinitialize deck with new difficulty
                            shuffle(Deck);
                            break;
                        }
                    } while (true);
                }
                break;

            case '4':
                displayStatistics(history);
                // Display betting statistics
                break;

            case '5':
                repeat = 'n';
                break;

            default:
                cout << "Invalid choice. Please select an option from the menu.\n";
        }
    } while (repeat == 'y');
}

//  GAME MAIN TEXT BRANCH HERE DON'Y MOVE THIS
void Game(deck& Deck, int& result, Bet& Bets, BetHistory& history) {
    queue<card> playerHand;
    // Player's hand using queue
    stack<card> dealerHand;
    // Dealer's hand using stack
    int playerTotal = 0;
    // Total value of player's hand
    int dealerTotal = 0;
    // Total value of dealer's hand
    char choice;
    // User input for decisions
    card drawnCard;
    // Holds the drawn card

    // Initial draws for player and dealer
    if (drawCard(Deck, drawnCard)) {
        playerHand.push(drawnCard);
    }

    cout << "The dealer's first card is the \n";
    if (drawCard(Deck, drawnCard)) {
        dealerHand.push(drawnCard);
        printCard(drawnCard);
        cout << endl;
    }

    if (drawCard(Deck, drawnCard)) {
        dealerHand.push(drawnCard);
    }

    cout << "\nYour two cards are the \n";
    if (drawCard(Deck, drawnCard)) {
        playerHand.push(drawnCard);
    }
    displayPlayerHand(playerHand, playerTotal);

    // Player's turn
    do {
        cout << "\nWould you like to hit or stay? Enter y or n: ";
        if (!validateYesNo(choice) || choice == 'n') {
            break;
        }

        cout << "\nYou drew:\n";
        if (drawCard(Deck, drawnCard)) {
            playerHand.push(drawnCard);
            displayPlayerHand(playerHand, playerTotal);
        }
        if (playerTotal > 21) {
            cout << "\nYou went bust and have lost your bet.\n";
            result = -1;
            history.addBet(Bets.getBet(), result);
            return;
        }
        if (playerTotal == 21) {
            cout << "\nBLACKJACK!\n";
            break;
        }
    } while (choice == 'y' && playerTotal < 21);

    // Dealer's turn
    cout << "\nDealer's cards are: \n";
    displayDealerHand(dealerHand, dealerTotal);

    // Adjust dealer behavior based on difficulty
    bool dealerHitsOnSoft17 = (Bets.getDifficulty() != 'c');

    // Dealer draws cards based on rules
    while (shouldDealerHit(dealerTotal, dealerHitsOnSoft17)) {
        cout << "\nDealer draws again: \n";
        if (drawCard(Deck, drawnCard)) {
            dealerHand.push(drawnCard);
            displayDealerHand(dealerHand, dealerTotal);
        }
    }

    if (dealerTotal > 21) {
        cout << "\nDealer has gone bust. You win the bet!\n";
        result = 1;
        history.addBet(Bets.getBet(), result);
        return;
    }

    // Compare totals to determine result
    if (playerTotal > dealerTotal) {
        cout << "\nWell played! You beat the house and won your bet.\n";
        result = 1;
    } else if (playerTotal < dealerTotal) {
        cout << "\nHouse has won and you've lost your bet.\n";
        result = -1;
    } else {
        cout << "\nTie! You don't lose anything.\n";
        result = 0;
    }
    history.addBet(Bets.getBet(), result);
}

// Shuffle function for the deck without using vectors
//good now dont change
void shuffle(deck& Deck) {
    list<card> shuffledDeck;
    // Create a new list for shuffled cards
    random_device rd;
    mt19937 g(rd());

    while (!Deck.cards.empty()) {
        size_t randIndex = g() % Deck.cards.size();
        // Generate a random index

        auto it = Deck.cards.begin();
        advance(it, randIndex);
        // Position the iterator at the random index

        shuffledDeck.splice(shuffledDeck.end(), Deck.cards, it);
        // Move the card to the shuffled deck
    }

    Deck.cards = move(shuffledDeck);
    // Assign the shuffled deck back to the original deck
}

// Draws a card from the deck and returns it
bool drawCard(deck& Deck, card& drawnCard) {
    if (!Deck.cards.empty()) {
        drawnCard = Deck.cards.front();
        // Remove the first card from the deck
        Deck.cards.pop_front();
        return true;
    } else {
        cout << "The deck is empty!\n";
        return false;
    }
}

// Displays the player's hand and calculates the total
void displayPlayerHand(queue<card> playerHand, int& total) {
    total = 0;
    list<int> cardValuesList;

    // Collect card values
    while (!playerHand.empty()) {
        card currentCard = playerHand.front();
        printCard(currentCard);
        cardValuesList.push_back(cardValues[currentCard.rank]);
        playerHand.pop();
    }

    // Adjust for aces
    total = accumulate(cardValuesList.begin(), cardValuesList.end(), 0);
    int aceCount = count(cardValuesList.begin(), cardValuesList.end(), 11);

    while (aceCount > 0 && total > 21) {
        total -= 10;
        aceCount--;
    }

    cout << "Total: " << total << endl;
}

// Displays the dealer's hand and calculates the total
//fixed
void displayDealerHand(stack<card> dealerHand, int& total) {
    total = 0;
    list<int> cardValuesList;

    // Collect card values
    stack<card> tempStack;
    while (!dealerHand.empty()) {
        card currentCard = dealerHand.top();
        printCard(currentCard);
        cardValuesList.push_back(cardValues[currentCard.rank]);
        tempStack.push(currentCard);
        dealerHand.pop();
    }

    // Restore the dealer's hand
    while (!tempStack.empty()) {
        dealerHand.push(tempStack.top());
        tempStack.pop();
    }

    // dont forget aces
    total = accumulate(cardValuesList.begin(), cardValuesList.end(), 0);
    int aceCount = count(cardValuesList.begin(), cardValuesList.end(), 11);

    while (aceCount > 0 && total > 21) {
        total -= 10;
        aceCount--;
    }

    cout << "Total: " << total << endl;
}

// Function to validate yes/no input
bool validateYesNo(char& choice) {
    cin >> choice;
    choice = tolower(choice);
    while (choice != 'y' && choice != 'n') {
        cout << "Invalid input. Please enter y or n: ";
        cin >> choice;
        choice = tolower(choice);
    }
    return true;
}

// Function to validate menu choice input
bool validateMenuChoice(char& choice, const string& validOptions) {
    cin >> choice;
    while (validOptions.find(choice) == string::npos) {
        cout << "Invalid input. Please enter a valid option (" << validOptions << "): ";
        cin >> choice;
    }
    return true;
}

// Function to validate bet amount input
bool validateBetAmount(float& betAmount) {
    cin >> betAmount;
    while (cin.fail() || betAmount < 100) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid bet amount. Please enter a valid amount (minimum 100): ";
        cin >> betAmount;
    }
    return true;
}

// Checks if the dealer should hit based difficulty level
bool shouldDealerHit(int dealerTotal, bool dealerHitsOnSoft17) {
    if (dealerTotal < 17) {
        return true;
    }
    if (dealerTotal == 17 && dealerHitsOnSoft17) {
        return true;
    }
    return false;
}

// Function to display betting statistics
void displayStatistics(const BetHistory& history) {
    cout << "\n--- Betting Statistics ---\n";
    cout << "Total Games Played: " << history.getTotalGames() << endl;
    cout << "Total Wins: " << history.getWins() << endl;
    cout << "Total Losses: " << history.getLosses() << endl;
    cout << "Total Ties: " << history.getTies() << endl;
    cout << "Win Rate: " << fixed << setprecision(2) << (history.getWinRate() * 100) << "%\n";
    cout << "Total Earnings: $" << history.getTotalEarnings() << endl;
}
