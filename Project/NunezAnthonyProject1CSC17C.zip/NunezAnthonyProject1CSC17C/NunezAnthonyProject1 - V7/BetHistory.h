
/* 
 * File:   BetHistory.h
 * Author: antho
 *
 * Created on November 9, 2024, 8:60 AM
 */

#ifndef BETHISTORY_H
#define BETHISTORY_H

#include <vector>

class BetHistory {
private:
    struct BetRecord {
        float amount;
        // The bet amount
        int result;
        // Result of the bet (1: win, -1: loss, 0: tie)
    };
    std::vector<BetRecord> history;
    // Vector to store bet records

public:
    void addBet(float amount, int result);
    // Adds a bet record to the history

    int getTotalGames() const;
    // Gets the total number of games played

    int getWins() const;
    // Gets the total number of wins

    int getLosses() const;
    // Gets the total number of losses

    int getTies() const;
    // Gets the total number of ties

    float getWinRate() const;
    // Gets the win rate

    float getTotalEarnings() const;
    // Gets the total earnings
};

#endif /* BETHISTORY_H */
