/*
 * File:   BlackJackV2.cpp
 * Author: Anthony Nunez
 *
 * Created on October 28, 2022, 12:40 PM
 */

#include <iostream>
#include <cstring>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <vector>
#include <ctime>
using namespace std;


// enumerated ranks and suits, maps out the actual words to the cards to
//organize it better.
enum Suit {Diamonds, Clubs, Hearts, Spades};
enum Rank {Ace,Two,Three,Four,Five,Six,Seven,Eight,Nine,Ten,Jack,Queen,King};

//Struct for cards, that hold all the distinctions in the deck besides card value
struct card {
	Suit suit;
	Rank rank;
        int suitNumber = 4;
        int rankNumber = 13;
};
//struct for deck specifications using vector
struct deck {
    vector<card> cards;
    string cardBack;
    int deckSize = 52;
};

//prototypes
void start();
void menu(deck& Deck);
void startUp(deck&);
void shuffle(deck& deck);
void printDeck(const deck& deck);
void printCard(const card& Card);
void drawCard(deck&,vector<card>& player, vector<card>& dealer);
void displayDrawn(const vector<card>& totalCards);

int main(int argc, char** argv) {
    //old shuffle wasn't giving a different shuffle from run to run, 
    //so i remembered the random number seed from the lecture you did 
    srand(static_cast<unsigned int>(time(0)));
    //variable for deck
    deck cardDeck;
    

    startUp(cardDeck);
    shuffle(cardDeck);
    printDeck(cardDeck);
    menu(cardDeck);
    
    return 0;
}

//starts up and initializes the decka and assigns all of the values
//figured out it was better to pass by reference for a deck of cards
void startUp(deck& cardDeck){
    
    card cardId;
    //nested for loops to go through the entire deck based on suit and rank
    for(int s = 0; s < cardId.suitNumber; s++) //suit
    {
        
        for(int r = 0; r < cardId.rankNumber; r++) //rank
        {
            //converting the local numbers of s and r and mapping them
            //to the enumerated Suit and Rank
        cardId.suit = Suit(s);
        cardId.rank = Rank(r);
                    
        cardDeck.cards.push_back(cardId);
        }
    }
    
    
}

//prints all values set by void startup
void printDeck(const deck& Deck){
    
    //for loop that goes through each card in the vector from deck and prints out their suit and rank
    for (card cardId : Deck.cards)
        {
        printCard(cardId);
        }
}

//seperate function to show singular card for drawCard function
void printCard(const card& Card)
{
    cout << "Rank = " << Card.rank << " ";
    cout << "Suit = " << Card.suit << "\n";
}

//menu function that will display and allow you to input choices on blackjack
void menu(deck& Deck){
    
    //variables for player and dealer cards
    vector<card> player;
    vector<card> dealer;
    
    //not sure how many more options it might have for now
    char choice;
    cout << "BlackJack: Project 1\n";
    cout << "1. Play Game\n";
    cout << "2: Display rules\n";
    cin >> choice;
    
    switch(choice)
    {
        
        
        case '1':
              
            cout << " your first card is a \n";
            drawCard(Deck, player, dealer);
            displayDrawn(player);
            break;
        
            
        case'2':
            
            
            break;
        
        
       
    }
    
    
    
}

//decided to shuffle,
//capitilized Deck in the pass by reference so it wouldn't conflict with "deck"
void shuffle(deck& Deck) {
    
    //deck struct variable for the deck post shuffle
    deck shuffledDeck;
    
    //while deck vector is not empty keep looping
    while (!Deck.cards.empty())
        {
        size_t rand_index = rand() % Deck.cards.size(); 
        //using rand_index, places one of the cards from deck into shuffledDeck
        //using push_back to insert it at the end of the vector
        shuffledDeck.cards.push_back(Deck.cards[rand_index]); 
        //removes card at location of rand_index
        Deck.cards.erase(Deck.cards.begin() + rand_index);
        }
    //reassigns the new shuffledDeck into deck
    Deck = shuffledDeck;
}

//function to draw card and attach it to player and dealer variables
void drawCard(deck& Deck,vector<card>& player, vector<card>& dealer)
{
    player.push_back(Deck.cards[0]);
    Deck.cards.erase(Deck.cards.begin());
    
}

//displays the card drawn, slightly messy and might cleanup later
void displayDrawn(const vector<card>& totalCards)
{
    for (card cardDraw : totalCards)
    {
        printCard(cardDraw);
    }
}