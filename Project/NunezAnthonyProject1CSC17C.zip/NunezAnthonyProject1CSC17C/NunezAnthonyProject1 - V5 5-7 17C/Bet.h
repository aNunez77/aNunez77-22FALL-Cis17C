/* 
 * File:   Bet.h
 * Author: Anthony Nunez
 *
 * Created on December 17, 2022, 12:49 PM
 */

#ifndef BET_H
#define BET_H

class Bet {
private:
    float bet;       // Bet amount when starting blackjack
    float payout;
    float bank;
    char difficulty;

public:
    Bet(float betAmnt, char betDifficulty);  // Constructor
    //changed Bankstore to allow for Wins Losses and ties
    void BankStore(int result, char& repeat);
    //added setbet and difficulty to change values after its already constructed
    void setBet(float newBet);
    void setDifficulty(char newDifficulty);
};

#endif /* BET_H */
