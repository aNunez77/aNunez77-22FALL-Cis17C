/*
 * File:   BlackJack.cpp
 * Author: Anthony Nunez
 *
 * Created on October 25, 2024, 8:10 PM
 */

#include <iostream>
#include <cstring>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <list>
#include <ctime>
#include <random>
#include "Bet.h"
using namespace std;

// Enumerated ranks and suits
enum Suit { Diamonds, Clubs, Hearts, Spades };
enum Rank { Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King };

// Struct for cards
struct card {
    Suit suit;
    Rank rank;
    int suitNumber = 4;
    int rankNumber = 13;
};

// Struct for deck specifications using list
struct deck {
    list<card> cards;
    int deckSize = 52;
};

// Function prototypes
void menu(deck& Deck);
void startUp(deck&);
void shuffle(deck& Deck);
void printDeck(deck& Deck);
void printCard(card& Card);
void drawCard(deck& Deck, list<card>& hand);
void displayDrawn(list<card>& totalCards, int& total);
void cardValue(card& Card, int& total);
void Game(deck& Deck, int& result);

int main(int argc, char** argv) {
    // Seed the random number generator
    srand(static_cast<unsigned int>(time(0)));
    // Initialize and shuffle the deck
    deck cardDeck;
    startUp(cardDeck);
    shuffle(cardDeck);
    // Start the game menu
    menu(cardDeck);
    return 0;
}

// Initializes the deck and assigns all of the values
void startUp(deck& cardDeck) {
    card cardId;
    // Nested loops to create the deck
    for (int s = 0; s < cardId.suitNumber; s++) { // Suit
        for (int r = 0; r < cardId.rankNumber; r++) { // Rank
            cardId.suit = Suit(s);
            cardId.rank = Rank(r);
            cardDeck.cards.push_back(cardId);
        }
    }
}

// Prints the entire deck (for debugging purposes)
void printDeck(deck& Deck) {
    for (auto& cardId : Deck.cards) {
        printCard(cardId);
    }
}

// Prints a single card
void printCard(card& Card) {
    string rankName[13] = { "Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight",
                            "Nine", "Ten", "Jack", "Queen", "King" };
    string suitName[4] = { "Diamonds", "Clubs", "Hearts", "Spades" };

    cout << rankName[Card.rank] << " of ";
    cout << suitName[Card.suit] << ", ";
}

// Menu function that displays options and handles user input
void menu(deck& Deck) {
    float betAmount = 100;
    char difficulty = 'c';
    char choice;
    char repeat = 'y';
    Bet Bets(betAmount, difficulty); // Use proper constructor

    // Game loop
    do {
        cout << "\nBlackJack: Project 1\n";
        cout << "1. Play Game\n";
        cout << "2. Display rules\n";
        cout << "3. Change bet and difficulty settings\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case '1': {
                int result = 0;
                Game(Deck, result);
                Bets.BankStore(result, repeat);
                if (repeat != 'n') {
                    cout << "Would you like to play again? (y/n): ";
                    cin >> repeat;
                    while (repeat != 'y' && repeat != 'n') {
                        cout << "Incorrect input, please enter y or n: ";
                        cin >> repeat;
                    }
                    if (repeat == 'y') {
                        if (Deck.cards.size() < 15) {
                            // Reinitialize and shuffle the deck if low on cards
                            startUp(Deck);
                            shuffle(Deck);
                        }
                    }
                }
                break;
            }

            case '2':
                cout << "\n--- Game Rules ---\n";
                cout << "The goal of blackjack is to reach a total of 21 with your combined cards.\n";
                cout << "Each card rank is allocated to its respective value with exceptions for face cards and aces.\n";
                cout << "Face cards are worth 10 and aces are worth 11 unless the total is over 21, in which case they become 1.\n";
                cout << "The dealer starts with two cards, one face down until you are done drawing.\n";
                cout << "If the dealer busts by going over 21 or you have a higher value than them under 21, you win.\n";
                break;

            case '3':
                cout << "Your current bet is at " << betAmount << endl;
                cout << "The balance you start at is 500\n";
                cout << "c: Casual, 1 deck shoe, dealer stands on soft 17, 1.2 payout rate\n";
                cout << "n: Normal, 2 deck shoe, dealer hits on soft 17, 1.5 payout rate\n";
                cout << "v: Vegas, 8 deck shoe, dealer hits on soft 17, 1.8 payout rate\n";
                cout << "Current difficulty is: " << difficulty << endl;
                cout << "Would you like to change bet? (y/n): ";
                cin >> choice;
                while (choice != 'y' && choice != 'n') {
                    cout << "Incorrect input, please enter y or n: ";
                    cin >> choice;
                }

                if (choice == 'y') {
                    cout << "Enter new bet amount of 100 minimum: ";
                    cin >> betAmount;
                    while (betAmount < 100) {
                        cout << "Value of bet must be at least 100\n";
                        cin >> betAmount;
                    }
                    Bets.setBet(betAmount);
                }

                cout << "Would you like to change difficulty? (y/n): ";
                cin >> choice;
                while (choice != 'y' && choice != 'n') {
                    cout << "Incorrect input, please enter y or n: ";
                    cin >> choice;
                }

                if (choice == 'y') {
                    do {
                        cout << "Select your difficulty \n c: Casual \nn: Normal \nv: Vegas\n";
                        cin >> difficulty;
                        if (difficulty != 'c' && difficulty != 'n' && difficulty != 'v') {
                            cout << "Incorrect input, please input either c, n, or v\n";
                        }
                    } while (difficulty != 'c' && difficulty != 'n' && difficulty != 'v');
                    Bets.setDifficulty(difficulty);
                }
                break;

            case '4':
                repeat = 'n';
                break;

            default:
                cout << "Invalid choice. Please select an option from the menu.\n";
        }
    } while (repeat == 'y');
}

// Implementation of Bet class methods

Bet::Bet(float betAmnt, char betDifficulty) {
    bet = betAmnt;
    difficulty = betDifficulty;
    bank = 500;
    if (difficulty == 'c') {
        payout = 1.20f;
    } else if (difficulty == 'n') {
        payout = 1.50f;
    } else if (difficulty == 'v') {
        payout = 1.80f;
    }
}

void Bet::BankStore(int result, char& repeat) {
    if (result == 1) { // Win
        bank = bank + (bet * payout);
        cout << "\nYou won! Your payout is " << bet * payout << ".\n";
    } else if (result == -1) { // Loss
        bank = bank - bet;
        cout << "\nYou lost. You lost your bet of " << bet << ".\n";
    } else {
        cout << "\nIt's a tie. You neither win nor lose money.\n";
    }
    cout << "Your balance is now " << bank << endl;
    if (bank <= 0) {
        cout << "You have run out of money!\n";
        repeat = 'n';
    }
}

void Bet::setBet(float newBet) {
    bet = newBet;
}

void Bet::setDifficulty(char newDifficulty) {
    difficulty = newDifficulty;
    if (difficulty == 'c') {
        payout = 1.20f;
    } else if (difficulty == 'n') {
        payout = 1.50f;
    } else if (difficulty == 'v') {
        payout = 1.80f;
    }
}

// Game function that handles the blackjack gameplay
void Game(deck& Deck, int& result) {
    list<card> player;
    list<card> dealer;
    int playerTotal = 0;
    int dealerTotal = 0;
    char choice;

    // Initial draws
    drawCard(Deck, player);
    cout << "The dealer's first card is the \n";
    drawCard(Deck, dealer);
    displayDrawn(dealer, dealerTotal);
    drawCard(Deck, dealer);

    cout << "\nYour two cards are the \n";
    drawCard(Deck, player);
    displayDrawn(player, playerTotal);

    // Player's turn
    do {
        cout << "\nWould you like to hit or stay? Enter y or n: ";
        cin >> choice;

        if (choice == 'y') {
            cout << "\nYou drew:\n";
            drawCard(Deck, player);
            displayDrawn(player, playerTotal);
        }
        if (playerTotal > 21) {
            cout << "\nYou went bust and have lost your bet.\n";
            result = -1;
            return;
        }
        if (playerTotal == 21) {
            cout << "\nBLACKJACK!\n";
            break;
        }
    } while (choice == 'y' && playerTotal < 21);

    // Dealer's turn
    cout << "\nDealer's cards are: \n";
    displayDrawn(dealer, dealerTotal);

    while (dealerTotal < 17) {
        cout << "\nDealer draws again: \n";
        drawCard(Deck, dealer);
        displayDrawn(dealer, dealerTotal);
    }

    if (dealerTotal > 21) {
        cout << "\nDealer has gone bust. You win the bet!\n";
        result = 1;
        return;
    }

    // Compare totals to determine result
    if (playerTotal > dealerTotal) {
        cout << "\nWell played! You beat the house and won your bet.\n";
        result = 1;
    } else if (playerTotal < dealerTotal) {
        cout << "\nHouse has won and you've lost your bet.\n";
        result = -1;
    } else {
        cout << "\nTie! You don't lose anything.\n";
        result = 0;
    }
}

// Shuffle function for the deck -now without vectors
void shuffle(deck& Deck) {
    // Create a new list for shuffled cards
    list<card> shuffledDeck;
    random_device rd;
    mt19937 g(rd());

    while (!Deck.cards.empty()) {
        // Generate a random index
        size_t randIndex = g() % Deck.cards.size();

        // Get an iterator to the random position
        auto it = Deck.cards.begin();
        advance(it, randIndex);

        // Move the card to the shuffled deck
        shuffledDeck.splice(shuffledDeck.end(), Deck.cards, it);
    }

    // Assign the shuffled deck back to the original deck
    Deck.cards = move(shuffledDeck);
}

// Draws a card from the deck and adds it to the hand
void drawCard(deck& Deck, list<card>& hand) {
    if (!Deck.cards.empty()) {
        hand.push_back(Deck.cards.front());
        Deck.cards.pop_front();
    } else {
        cout << "The deck is empty!\n";
    }
}

// Displays the cards in hand and calculates the total
void displayDrawn(list<card>& totalCards, int& total) {
    total = 0;
    int aceCount = 0;
    for (auto& cardDraw : totalCards) {
        printCard(cardDraw);
        cardValue(cardDraw, total);
        if (cardDraw.rank == Ace) {
            aceCount += 1;
        }
    }
    // Adjust for aces if total > 21
    while (aceCount > 0 && total > 21) {
        total -= 10;
        aceCount--;
    }
    cout << "Total: " << total << endl;
}

// Calculates the value of a single card and adds it to the total
void cardValue(card& Card, int& total) {
    int value = Card.rank + 1;

    if (value > 10) {
        value = 10;
    }
    if (value == 1) { // Ace
        value = 11;
    }
    total += value;
}
