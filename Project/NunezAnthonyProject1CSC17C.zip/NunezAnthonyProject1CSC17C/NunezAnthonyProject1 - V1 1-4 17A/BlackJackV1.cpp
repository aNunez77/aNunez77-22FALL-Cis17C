/*
 * File:   BlackJackV1.cpp
 * Author: Anthony Nunez
 *
 * Created on October 28, 2022, 12:40 PM
 */

#include <iostream>
#include <cstring>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <vector>
using namespace std;


// enumerated ranks and suits, maps out the actual words to the cards to
//organize it better.
enum Suit {Diamonds, Clubs, Hearts, Spades};
enum Rank {Ace,Two,Three,Four,Five,Six,Seven,Eight,Nine,Ten,Jack,Queen,King};

//Struct for cards, that hold all the distinctions in the deck besides card value
struct card {
	Suit suit;
	Rank rank;
        int suitNumber = 4;
        int rankNumber = 13;
};
//struct for deck specifications using vector
struct deck {
    vector<card> cards;
    string cardBack;
    int deckSize = 52;
};

//prototypes
void start();
void menu();
void shuffle(deck& deck);
void startUp(deck&);
void printDeck(const deck& deck);

int main(int argc, char** argv) {
    
    //variable for deck
    deck cardDeck;
    

    startUp(cardDeck);
    printDeck(cardDeck);
    
    return 0;
}

//starts up and initializes the decka and assigns all of the values
//figured out it was better to pass by reference for a deck of cards
void startUp(deck& cardDeck){
    
    card cardId;
    //nested for loops to go through the entire deck based on suit and rank
    for(int s = 0; s < cardId.suitNumber; s++) //suit
    {
        
        for(int r = 0; r < cardId.rankNumber; r++) //rank
        {
            //converting the local numbers of s and r and mapping them
            //to the enumerated Suit and Rank
        cardId.suit = Suit(s);
        cardId.rank = Rank(r);
                    
        cardDeck.cards.push_back(cardId);
        }
    }
    
    
}

//prints all values set by void startup
void printDeck(const deck& Deck){
    
    //for loop that goes through each card in the vector from deck and prints out their suit and rank
    for (card cardId : Deck.cards)
    {
        cout << "rank = " << cardId.rank << " ";
        cout << "Suit = " << cardId.suit << "\n";
    }
}



//menu function that will display and allow you to input choices on blackjack
void menu(){
    
    //not sure how many more options it might have for now
    char choice;
    cout << "BlackJack: Project 1\n";
    cout << "1. Play Game\n";
    cout << "2: Display rules";
    cin >> choice;
    
    switch(choice)
    {
        
        
        case '1':
              
            
            break;
        
            
        case'2':
            
            
            break;
        
        
       
    }
    
    
    
}

//not sure if i'll shuffle or randomize when drawn
void shuffle(deck& Deck) {
    
    
}
