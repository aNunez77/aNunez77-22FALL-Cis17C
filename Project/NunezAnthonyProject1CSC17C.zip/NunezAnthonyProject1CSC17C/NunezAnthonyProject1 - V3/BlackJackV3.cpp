/*
 * File:   BlackJackV3.cpp
 * Author: Anthony Nunez
 *
 * Created on October 28, 2022, 12:40 PM
 */

#include <iostream>
#include <cstring>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <vector>
#include <ctime>
using namespace std;


// enumerated ranks and suits, maps out cards for easy use
enum Suit {Diamonds, Clubs, Hearts, Spades};
enum Rank {Ace,Two,Three,Four,Five,Six,Seven,Eight,Nine,Ten,Jack,Queen,King};

//Struct for cards, that hold all the distinctions in the deck besides card value
struct card {
	Suit suit;
	Rank rank;
        int suitNumber = 4;
        int rankNumber = 13;
};
//struct for deck specifications using vector
struct deck {
    vector<card> cards;
    int deckSize = 52; 
};



//prototypes
void start();
void menu(deck& Deck);
void startUp(deck&);
void shuffle(deck& deck);
void printDeck( deck& deck);
void printCard(card& Card);
void drawCard(deck&,vector<card>& player);
void dealerdrawCard(deck& Deck,vector<card>& dealer);
void displayDrawn(vector<card>& totalCards, int& total);
void cardValue(card& Card, int& total);

int main(int argc, char** argv) {
    //do while loop for if you want to replay
    //it causes the deck to reallocate and shuffle so it doesn't run out
    char replay;
    do{
    //old shuffle wasn't giving a different shuffle from run to run, 
    //so i remembered the random number seed from the lecture you did 
    srand(static_cast<unsigned int>(time(0)));
    //variable for deck
    deck cardDeck;
    startUp(cardDeck);
    shuffle(cardDeck);
    menu(cardDeck);
    cout << "would you like to play again, y or n";
    cin >> replay;
    }while(replay == 'y');
    return 0;
}

//starts up and initializes the decka and assigns all of the values
//figured out it was better to pass by reference for a deck of cards
void startUp(deck& cardDeck){
    
    card cardId;
    //nested for loops to go through the entire deck based on suit and rank
    for(int s = 0; s < cardId.suitNumber; s++) //suit
    {
        
        for(int r = 0; r < cardId.rankNumber; r++) //rank
        {
            //converting the local numbers of s and r and mapping them
            //to the enumerated Suit and Rank
        cardId.suit = Suit(s);
        cardId.rank = Rank(r);
                    
        cardDeck.cards.push_back(cardId);
        }
    }
}

//prints all values set by void startup
void printDeck(deck& Deck){
    
    //for loop that goes through each card in the vector from deck and prints out their suit and rank
    for (card cardId : Deck.cards)
        {
        printCard(cardId);
        }
}

//seperate function to show singular card for drawCard function
void printCard(card& Card)
{
    string rankName[13] = {"Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King"};
    string suitName[4] = {"Diamonds", "Clubs", "Hearts", "Spades"};
    
    cout << rankName[Card.rank] << " of ";
    cout << suitName[Card.suit] << ", ";
    
}

//menu function that will display and allow you to input choices on blackjack
void menu(deck& Deck){
    
    //variables for player and dealer cards
    vector<card> player;
    vector<card> dealer;
    //variables for player and dealer totals
    int playerTotal = 0;
    int dealerTotal = 0;
    char choice;
    cout << "BlackJack: Project 1\n";
    cout << "1. Play Game\n";
    cout << "2: Display rules\n";
    cin >> choice;
    
    switch(choice)
    {
           
        case '1':
              
            //draws players card and then dealers to reenact actual rules, then deals second card to both, with dealers face down
            drawCard(Deck, player);
            
            cout << "the dealers first card is the \n";
            dealerdrawCard(Deck, dealer);
            displayDrawn(dealer, dealerTotal);
            dealerdrawCard(Deck, dealer);
            
            cout << "\n\nyour two cards are the \n";
            drawCard(Deck, player);
            displayDrawn(player, playerTotal);
            
            //prompting if you would like to hit for another card or not in a do while loop
            do {
                cout << "\nwould you like to hit or stay, enter y or n \n";
                cin >> choice;

                if (choice == 'y')
                {
                    cout << "\nyour new cards are the\n";
                //set playerTotal to 0 because displayDrawn calculates all previous cards as well as current
                playerTotal = 0;
                drawCard(Deck, player);
                displayDrawn(player, playerTotal);
                }
                if (playerTotal > 21)
                    {
                    cout << "\nyou went bust and have lost your bet \n";
                    break;
                    }
                if (playerTotal == 21)
                {
                    cout << "BLACKJACK!";
                    break;
                }
            }while(choice == 'y');
            //extra break statemnt to exit the case 
            if (playerTotal > 21)
            {
                break;
            }
            
            cout << "\ndealers cards are: \n";
            //same principle with dealerTotal, will need to find a different method for when i expand this in the final
            dealerTotal = 0;
            displayDrawn(dealer, dealerTotal);
            
            while (dealerTotal < 17)
            {
                dealerTotal = 0;
                cout << "\ndealer draws again: \n";
                dealerdrawCard(Deck, dealer);
                displayDrawn(dealer, dealerTotal);
                
                if(dealerTotal > 21)
                {
                    cout << "\ndealer has gone bust you win the bet\n";
                    break;
                }
                
            }
            
            if(dealerTotal > 21)
            {
                break;
            }
            
            if(playerTotal > dealerTotal)
            {
                cout << "\nwell played you beat the house and won your bet" << endl;
            }
            else if (playerTotal < dealerTotal)
            {
                cout << "\nhouse has won and you've lost your bet\n";
            }
            else if (playerTotal = dealerTotal)
            {
                cout << "\nTie you don't lose anything\n";
            }
            break;
        
            
        case'2':
            
            cout << "the goal of blackjack is to reach a total of 21 with your combined cards\n";
            cout << "each card rank is allocated to its respective value with the exceptions of face cards and aces \n";
            cout << "face cards are worth 10 and aces are worth 11 unless the total is over 21 in which they become a 1";
            cout << "the dealer starts with two cards, one face down until you are done drawing\n";
            cout << "if the dealer busts by going over 21 or you have a higher value than them under 21 you win";
            break;
    }
}

//decided to shuffle,
//capitilized Deck in the pass by reference so it wouldn't conflict with "deck"
void shuffle(deck& Deck) {
    
    //deck struct variable for the deck post shuffle
    deck shuffledDeck;
    
    //while deck vector is not empty keep looping
    while (!Deck.cards.empty())
        {
        size_t rand_index = rand() % Deck.cards.size(); 
        //using rand_index, places one of the cards from deck into shuffledDeck
        //using push_back to insert it at the end of the vector
        shuffledDeck.cards.push_back(Deck.cards[rand_index]); 
        //removes card at location of rand_index
        Deck.cards.erase(Deck.cards.begin() + rand_index);
        }
    //reassigns the new shuffledDeck into deck
    Deck = shuffledDeck;
}

//function to draw card and attach it to player and dealer variables
void drawCard(deck& Deck,vector<card>& player)
{
    player.push_back(Deck.cards[0]);
    Deck.cards.erase(Deck.cards.begin());  
}
//seperate function for distinction, but mostly because i kept messing up the pass by reference
void dealerdrawCard(deck& Deck,vector<card>& dealer)
{
    dealer.push_back(Deck.cards[0]);
    Deck.cards.erase(Deck.cards.begin());  
}

//displays the card drawn, its messy but it's how i got it to work
void displayDrawn(vector<card>& totalCards, int& total)
{
    //have a bool ace here to check if the cards are an ace and allow it to be either 1 or 11
    bool ace;
    for (card cardDraw : totalCards)
    {
        printCard(cardDraw);
        cardValue(cardDraw, total);
        if(cardDraw.rank == 0)
        {
            ace = true;
        }
    }
    if(total > 21 && ace == true)
    {
        total = total - 10;
        ace = false;
    }
    cout << total;
}
//function for getting the value of the card you've drawn
void cardValue(card& Card, int& total)
{
    int value;
    value = Card.rank + 1;
    
    if(value > 10)
    {
        value = 10;
    }
    if(value == 1)
    {
        value = 11;
    }
    total += value;
}