/*
 * File:   BlackJack.cpp
 * Author: Anthony Nunez
 *
 * Created on October 28, 2022, 12:40 PM
 */

#include <iostream>
#include <cstring>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <vector>
#include <ctime>
#include "Bet.h"
using namespace std;


// enumerated ranks and suits, maps out cards for easy use
enum Suit {Diamonds, Clubs, Hearts, Spades};
enum Rank {Ace,Two,Three,Four,Five,Six,Seven,Eight,Nine,Ten,Jack,Queen,King};

//Struct for cards, that hold all the distinctions in the deck besides card value
struct card {
	Suit suit;
	Rank rank;
        int suitNumber = 4;
        int rankNumber = 13;
};
//struct for deck specifications using vector
struct deck {
    vector<card> cards;
    int deckSize = 52; 
};



//prototypes
void start();
void menu(deck& Deck);
void startUp(deck&);
void shuffle(deck& deck);
void printDeck(deck& deck);
void printCard(card& Card);
void drawCard(deck&,vector<card>& player);
void dealerdrawCard(deck& Deck,vector<card>& dealer);
void displayDrawn(vector<card>& totalCards, int& total);
void cardValue(card& Card, int& total);
void Game(deck& deck, bool& win);

int main(int argc, char** argv) {
    //do while loop for if you want to replay
    //it causes the deck to reallocate and shuffle so it doesn't run out
    char replay;
    do{
    //old shuffle wasn't giving a different shuffle from run to run, 
    //so i remembered the random number seed from the lecture you did 
    srand(static_cast<unsigned int>(time(0)));
    //variable for deck
    deck cardDeck;
    startUp(cardDeck);
    shuffle(cardDeck);
    menu(cardDeck);
    }while(replay == 'y');
    return 0;
}

//starts up and initializes the decka and assigns all of the values
//figured out it was better to pass by reference for a deck of cards
void startUp(deck& cardDeck){
    
    card cardId;
    //nested for loops to go through the entire deck based on suit and rank
    for(int s = 0; s < cardId.suitNumber; s++) //suit
    {
        
        for(int r = 0; r < cardId.rankNumber; r++) //rank
        {
            //converting the local numbers of s and r and mapping them
            //to the enumerated Suit and Rank
        cardId.suit = Suit(s);
        cardId.rank = Rank(r);
                    
        cardDeck.cards.push_back(cardId);
        }
    }
}

//prints all values set by void startup
void printDeck(deck& Deck){
    
    //for loop that goes through each card in the vector from deck and prints out their suit and rank
    for (card cardId : Deck.cards)
        {
        printCard(cardId);
        }
}

//seperate function to show singular card for drawCard function
void printCard(card& Card)
{
    string rankName[13] = {"Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King"};
    string suitName[4] = {"Diamonds", "Clubs", "Hearts", "Spades"};
    
    cout << rankName[Card.rank] << " of ";
    cout << suitName[Card.suit] << ", ";
    
}

void Bet::BankStore(bool win, float betAmnt, char repeat){
    
    if(win == true)
    {
        bank = bank + (betAmnt * payout);
    }
    else if( win == false)
    {
        bank = bank - betAmnt;
    }
    cout << "\nyour balance is now " << bank << endl;;
    if(bank <= 0)
    {
        repeat = 'n';
    }
}

//menu function that will display and allow you to input choices on blackjack
void menu(deck& Deck){
    float bet = 100;
    char difficulty = 'c';
    char choice;
    char repeat = 'y';
    bool win = false;
    Bet Bets;
    Bets.Construct(bet, difficulty);
    //do while for game
    do {
         
    cout << "BlackJack: Project 1\n";
    cout << "1. Play Game\n";
    cout << "2: Display rules\n";
    cout << "3: change bet and difficulty settings";
    cin >> choice;
    
    //initializes and shuffles deck again on repeats
    if(repeat == 'y' || repeat == 'Y')
    {
    srand(static_cast<unsigned int>(time(0)));
    deck cardDeck;
    startUp(cardDeck);
    shuffle(cardDeck);
    }
    
    switch(choice)
    {
           
        case '1':
              
            Game(Deck, win);
            Bets.BankStore(win, bet, repeat);
            cout << "would you like to play again y or n";
            cin >> repeat;
            if(repeat != 'y' && repeat != 'n')
            {
                do{
                cout << "incorrect input, please enter y or n\n";
                cin >> repeat;
                }while(repeat != 'y' && repeat != 'n');
            }

            break;
        
        case'2':
            
            cout << "the goal of blackjack is to reach a total of 21 with your combined cards\n";
            cout << "each card rank is allocated to its respective value with the exceptions of face cards and aces \n";
            cout << "face cards are worth 10 and aces are worth 11 unless the total is over 21 in which they become a 1\n";
            cout << "the dealer starts with two cards, one face down until you are done drawing\n";
            cout << "if the dealer busts by going over 21 or you have a higher value than them under 21 you win";
            break;
            
        case'3':
            cout << "your current bet is at " << bet << endl;
            cout << "the balance you start at is 500\n";
            cout << "c: casual, 1 deck shoe, dealer stand soft 17, 1.2 payout rate\n";
            cout << "n: normal, 2 deck shoe, dealer hit soft 17, 1.5 payout rate\n";
            cout << "v: Vegas, 8 deck shoe, dealer hit soft 17, 1.8 payout rate\n";
            cout << "current difficulty is: " << difficulty << endl;
            cout << "would you like to change bet? y or n";
            cin >> choice;
            if(choice != 'y' && choice != 'n')
            {
                do{
                cout << "incorrect input, please enter y or n\n";
                cin >> choice;
                }while(choice != 'y' && choice != 'n');
            }
            
            if(choice == 'y')
            {
                cout << "enter new bet amount of 100 minimum\n";
                cin >> bet;
                if(bet < 100)
                {
                    do{
                    cout << "value of bet must at least be 100\n";
                    cin >> bet;
                    }while(bet < 100);
                }
            }
            
            cout << "would you like to change difficulty y or n\n";
            cin >> choice;
            
            if(choice != 'y' && choice != 'n')
            {
                do{
                cout << "incorrect input, please enter y or n\n";
                cin >> choice;
                }while(choice != 'y' && choice != 'n');
            }
            
            if(choice == 'y')
            {
                do {
                cout << "select your difficulty \n c: casual \nn: normal \nv: Vegas\n";
                cin >> difficulty;
                if(difficulty != 'c' && difficulty != 'n' && difficulty != 'v')
                {
                    cout << "incorrect input please input either c, n, or v\n";
                }
                }while(difficulty != 'c' && difficulty != 'n' && difficulty != 'v');
            }
            break;
    } 
    
    }while(repeat == 'y' || repeat == 'Y');
}
//constructor
Bet::Construct(float betAmnt,char betDifficulty)
{
    bet = betAmnt;
    difficulty = betDifficulty;
    bank = 500;
    if(difficulty == 'c')
    {
        payout = 1.20;
    }
    if(difficulty == 'n')
    {
        payout = 1.50;
    }
    if(difficulty == 'v')
    {
        payout = 1.80;
    }

}


void Game(deck& Deck, bool& win){
    vector<card> player;
    vector<card> dealer;
    int playerTotal = 0;
    int dealerTotal = 0;
    char choice;
    
    //draws players card and then dealers to reenact actual rules, then deals second card to both, with dealers face down
            drawCard(Deck, player);
            
            cout << "the dealers first card is the \n";
            drawCard(Deck, dealer);
            displayDrawn(dealer, dealerTotal);
            drawCard(Deck, dealer);
            
            cout << "\n\nyour two cards are the \n";
            drawCard(Deck, player);
            displayDrawn(player, playerTotal);
            
            //prompting if you would like to hit for another card or not in a do while loop
            do {
                cout << "\nwould you like to hit or stay, enter y or n \n";
                cin >> choice;

                if (choice == 'y')
                {
                    cout << "\nyour new cards are the\n";
                //set playerTotal to 0 because displayDrawn calculates all previous cards as well as current
                drawCard(Deck, player);
                displayDrawn(player, playerTotal);
                }
                if (playerTotal > 21)
                    {
                    cout << "\nyou went bust and have lost your bet \n";
                    playerTotal = -1;
                    }
                if (playerTotal == 21)
                {
                    cout << "\nBLACKJACK!";
                }
            }while(choice == 'y' && playerTotal != -1);
            
            cout << "\ndealers cards are: \n";
            displayDrawn(dealer, dealerTotal);
            
            
            while (dealerTotal < 17)
            {
                cout << "\ndealer draws again: \n";
                drawCard(Deck, dealer);
                displayDrawn(dealer, dealerTotal);         
            }
            
            if(dealerTotal > 21)
            {
                cout << "\ndealer has gone bust you win the bet\n";
                dealerTotal = 0;
            }
            
            if(playerTotal > dealerTotal && playerTotal <= 21)
            {
                cout << "\nwell played you beat the house and won your bet" << endl;
                win = true;
            }
            if (playerTotal < dealerTotal && dealerTotal <=21)
            {
                cout << "\nhouse has won and you've lost your bet\n";
                win = false;
            }
            if (playerTotal == dealerTotal && playerTotal <=21)
            {
                cout << "\nTie you don't lose anything\n";
            }
}


//decided to shuffle,
//capitilized Deck in the pass by reference so it wouldn't conflict with "deck"
void shuffle(deck& Deck) {
    
    //deck struct variable for the deck post shuffle
    deck shuffledDeck;
    
    //while deck vector is not empty keep looping
    while (!Deck.cards.empty())
        {
        size_t rand_index = rand() % Deck.cards.size(); 
        //using rand_index, places one of the cards from deck into shuffledDeck
        //using push_back to insert it at the end of the vector
        shuffledDeck.cards.push_back(Deck.cards[rand_index]); 
        //removes card at location of rand_index
        Deck.cards.erase(Deck.cards.begin() + rand_index);
        }
    //reassigns the new shuffledDeck into deck
    Deck = shuffledDeck;
}

//function to draw card and attach it to player and dealer variables
//also figured out how to do one draw function
void drawCard(deck& Deck,vector<card>& draw)
{
    draw.push_back(Deck.cards[0]);
    Deck.cards.erase(Deck.cards.begin());  
}

//displays the card drawn, its messy but it's how i got it to work
void displayDrawn(vector<card>& totalCards, int& total)
{
    total = 0;
    //changed ace to a count so multiple aces can occour correctly 
    int aceCount = 0;
    for (card cardDraw : totalCards)
    {
        printCard(cardDraw);
        cardValue(cardDraw, total);
        if(cardDraw.rank == 0)
        {
            aceCount += 1;
        }
    }
    while(aceCount > 0 && total > 21) 
    {
        total = total - 10;
        aceCount--;
    }
    cout << total;
}
//function for getting the value of the card you've drawn
void cardValue(card& Card, int& total)
{
    int value;
    value = Card.rank + 1;
    
    if(value > 10)
    {
        value = 10;
    }
    if(value == 1)
    {
        value = 11;
    }
    total += value;
}