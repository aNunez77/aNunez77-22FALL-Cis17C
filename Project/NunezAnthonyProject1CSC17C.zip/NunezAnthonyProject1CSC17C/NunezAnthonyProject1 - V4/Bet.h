/* 
 * File:   Bet.h
 * Author: Anthony Nunez
 *
 * Created on December 17, 2022, 12:49 PM
 */

#ifndef BET_H
#define BET_H

class Bet{
private:
    float bet; //bet amount when starting blackjack
    float payout;
    float bank;
    char difficulty;
public:
    Construct(float,char); //constructor
    void BankStore(bool win, float betAmnt, char repeat);
};


#endif /* BET_H */

