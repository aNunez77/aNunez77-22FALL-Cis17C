/*
 * File:   BlackJack.cpp
 * Author: Anthony Nunez
 *
 * Created on November 2, 2024, 3:23 PM
 */


#include <iostream>
#include <cstring>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <list>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <ctime>
#include <random>
#include "Bet.h"

using namespace std;

// Enumerated ranks and suits
enum Suit { Diamonds, Clubs, Hearts, Spades };
enum Rank { Ace = 1, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King };

// Map to associate card ranks with their values
map<Rank, int> cardValues = {
    {Ace, 11}, {Two, 2}, {Three, 3}, {Four, 4}, {Five, 5},
    {Six, 6}, {Seven, 7}, {Eight, 8}, {Nine, 9}, {Ten, 10},
    {Jack, 10}, {Queen, 10}, {King, 10}
};

// Struct for cards
struct card {
    Suit suit;
    Rank rank;
    int suitNumber = 4;
    int rankNumber = 13;
};

// Struct for deck specifications using list
struct deck {
    list<card> cards;
    int deckSize = 52;
};

// Set to track dealt cards
set<pair<Suit, Rank>> dealtCards;

// Function prototypes
void menu(deck& Deck);
void startUp(deck&);
void shuffle(deck& Deck);
void printDeck(deck& Deck);
void printCard(const card& Card);
bool drawCard(deck& Deck, card& drawnCard);
void displayPlayerHand(queue<card> playerHand, int& total);
void displayDealerHand(stack<card> dealerHand, int& total);
void Game(deck& Deck, int& result);
void calculateTotal(queue<card> hand, int& total);
void calculateTotal(stack<card> hand, int& total);

int main(int argc, char** argv) {
    // Seed the random number generator
    srand(static_cast<unsigned int>(time(0)));

    // Initialize and shuffle the deck
    deck cardDeck;
    startUp(cardDeck);
    shuffle(cardDeck);

    // Start the game menu
    menu(cardDeck);
    return 0;
}

// Initializes the deck and assigns all of the values
void startUp(deck& cardDeck) {
    card cardId;

    // Nested loops to create the deck
    for (int s = 0; s < cardId.suitNumber; s++) { // Suit
        for (int r = 1; r <= cardId.rankNumber; r++) { // Rank
            cardId.suit = Suit(s);
            cardId.rank = Rank(r);
            cardDeck.cards.push_back(cardId);
        }
    }

    // Sort the deck before shuffling (Organization Algorithm)
    cardDeck.cards.sort([](const card& a, const card& b) {
        if (a.suit == b.suit)
            return a.rank < b.rank;
        return a.suit < b.suit;
    });
}

// Prints the entire deck (for when things mess up)
void printDeck(deck& Deck) {
    for (const auto& cardId : Deck.cards) {
        printCard(cardId);
    }
}

// Prints a single card
void printCard(const card& Card) {
    string rankName[13] = { "Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight",
                            "Nine", "Ten", "Jack", "Queen", "King" };
    string suitName[4] = { "Diamonds", "Clubs", "Hearts", "Spades" };

    cout << rankName[Card.rank - 1] << " of ";
    cout << suitName[Card.suit] << ", ";
}

// Menu function
void menu(deck& Deck) {
    float betAmount = 100;
    char difficulty = 'c';
    char choice;
    char repeat = 'y';
    Bet Bets(betAmount, difficulty); // Use the right constructor

    // Game loop
    do {
        cout << "\nBlackJack: Project 2\n";
        cout << "1. Play Game\n";
        cout << "2. Display rules\n";
        cout << "3. Change bet and difficulty settings\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case '1': {
                int result = 0;
                Game(Deck, result);
                Bets.BankStore(result, repeat);
                if (repeat != 'n') {
                    cout << "Would you like to play again? (y/n): ";
                    cin >> repeat;
                    while (repeat != 'y' && repeat != 'n') {
                        cout << "Incorrect input, please enter y or n: ";
                        cin >> repeat;
                    }
                    if (repeat == 'y') {
                        if (Deck.cards.size() < 15) {
                            // Reinitialize and shuffle the deck if low on cards
                            startUp(Deck);
                            shuffle(Deck);
                            dealtCards.clear(); // Clear the set of dealt cards
                        }
                    }
                }
                break;
            }

            case '2':
                cout << "\n--- Game Rules ---\n";
                cout << "The goal of blackjack is to reach a total of 21 with your combined cards.\n";
                cout << "Each card rank is allocated to its respective value with exceptions for face cards and aces.\n";
                cout << "Face cards are worth 10 and aces are worth 11 unless the total is over 21, in which case they become 1.\n";
                cout << "The dealer starts with two cards, one face down until you are done drawing.\n";
                cout << "If the dealer busts by going over 21 or you have a higher value than them under 21, you win.\n";
                break;

            case '3':
                cout << "Your current bet is at " << betAmount << endl;
                cout << "The balance you start at is 500\n";
                cout << "c: Casual, 1 deck shoe, dealer stands on soft 17, 1.2 payout rate\n";
                cout << "n: Normal, 2 deck shoe, dealer hits on soft 17, 1.5 payout rate\n";
                cout << "v: Vegas, 8 deck shoe, dealer hits on soft 17, 1.8 payout rate\n";
                cout << "Current difficulty is: " << difficulty << endl;
                cout << "Would you like to change bet? (y/n): ";
                cin >> choice;
                while (choice != 'y' && choice != 'n') {
                    cout << "Incorrect input, please enter y or n: ";
                    cin >> choice;
                }

                if (choice == 'y') {
                    cout << "Enter new bet amount of 100 minimum: ";
                    cin >> betAmount;
                    while (betAmount < 100) {
                        cout << "Value of bet must be at least 100\n";
                        cin >> betAmount;
                    }
                    Bets.setBet(betAmount);
                }

                cout << "Would you like to change difficulty? (y/n): ";
                cin >> choice;
                while (choice != 'y' && choice != 'n') {
                    cout << "Incorrect input, please enter y or n: ";
                    cin >> choice;
                }

                if (choice == 'y') {
                    do {
                        cout << "Select your difficulty \n c: Casual \nn: Normal \nv: Vegas\n";
                        cin >> difficulty;
                        if (difficulty != 'c' && difficulty != 'n' && difficulty != 'v') {
                            cout << "Incorrect input please input either c, n, or v\n";
                        }
                    } while (difficulty != 'c' && difficulty != 'n' && difficulty != 'v');
                    Bets.setDifficulty(difficulty);
                }
                break;

            case '4':
                repeat = 'n';
                break;

            default:
                cout << "Invalid choice. Please select an option from the menu.\n";
        }
    } while (repeat == 'y');
}

// Implementation of Bet class methods
//maybe move bet in in later version to different area, awkward spot as i dont edit this much

Bet::Bet(float betAmnt, char betDifficulty) {
    bet = betAmnt;
    difficulty = betDifficulty;
    bank = 500;
    if (difficulty == 'c') {
        payout = 1.20f;
    } else if (difficulty == 'n') {
        payout = 1.50f;
    } else if (difficulty == 'v') {
        payout = 1.80f;
    }
}

void Bet::BankStore(int result, char& repeat) {
    if (result == 1) { // Win
        bank = bank + (bet * payout);
        cout << "\nYou won! Your payout is " << bet * payout << ".\n";
    } else if (result == -1) { // Loss
        bank = bank - bet;
        cout << "\nYou lost. You lost your bet of " << bet << ".\n";
    } else {
        cout << "\nIt's a tie. You neither win nor lose money.\n";
    }
    cout << "Your balance is now " << bank << endl;
    if (bank <= 0) {
        cout << "You have run out of money!\n";
        repeat = 'n';
    }
}

void Bet::setBet(float newBet) {
    bet = newBet;
}
//deprecated difficulty, fix in next version decks are annoying to initialize make them easier
void Bet::setDifficulty(char newDifficulty) {
    difficulty = newDifficulty;
    if (difficulty == 'c') {
        payout = 1.20f;
    } else if (difficulty == 'n') {
        payout = 1.50f;
    } else if (difficulty == 'v') {
        payout = 1.80f;
    }
}

// Game function that handles the blackjack gameplay
void Game(deck& Deck, int& result) {
    queue<card> playerHand;
    stack<card> dealerHand;
    int playerTotal = 0;
    int dealerTotal = 0;
    char choice;
    card drawnCard;

    // Initial draws
    if (drawCard(Deck, drawnCard)) {
        playerHand.push(drawnCard);
    }

    cout << "The dealer's first card is the \n";
    if (drawCard(Deck, drawnCard)) {
        dealerHand.push(drawnCard);
        printCard(drawnCard);
        cout << endl;
    }

    if (drawCard(Deck, drawnCard)) {
        dealerHand.push(drawnCard);
    }

    cout << "\nYour two cards are the \n";
    if (drawCard(Deck, drawnCard)) {
        playerHand.push(drawnCard);
    }
    displayPlayerHand(playerHand, playerTotal);

    // Player's turn
    do {
        cout << "\nWould you like to hit or stay? Enter y or n: ";
        cin >> choice;

        if (choice == 'y') {
            cout << "\nYou drew:\n";
            if (drawCard(Deck, drawnCard)) {
                playerHand.push(drawnCard);
                displayPlayerHand(playerHand, playerTotal);
            }
            if (playerTotal > 21) {
                cout << "\nYou went bust and have lost your bet.\n";
                result = -1;
                return;
            }
            if (playerTotal == 21) {
                cout << "\nBLACKJACK!\n";
                break;
            }
        }
    } while (choice == 'y' && playerTotal < 21);

    // Dealer's turn
    cout << "\nDealer's cards are: \n";
    displayDealerHand(dealerHand, dealerTotal);

    while (dealerTotal < 17) {
        cout << "\nDealer draws again: \n";
        if (drawCard(Deck, drawnCard)) {
            dealerHand.push(drawnCard);
            displayDealerHand(dealerHand, dealerTotal);
        }
    }

    if (dealerTotal > 21) {
        cout << "\nDealer has gone bust. You win the bet!\n";
        result = 1;
        return;
    }

    // Compare totals to determine result
    if (playerTotal > dealerTotal) {
        cout << "\nWell played! You beat the house and won your bet.\n";
        result = 1;
    } else if (playerTotal < dealerTotal) {
        cout << "\nHouse has won and you've lost your bet.\n";
        result = -1;
    } else {
        cout << "\nTie! You don't lose anything.\n";
        result = 0;
    }
}

// Shuffle function for the deck without using vectors
void shuffle(deck& Deck) {
    // Create a new list for shuffled cards
    list<card> shuffledDeck;
    random_device rd;
    mt19937 g(rd());

    while (!Deck.cards.empty()) {
        // make a random index
        size_t randIndex = g() % Deck.cards.size();

        // randomly positions the thing
        auto it = Deck.cards.begin();
        advance(it, randIndex);

        // moves card specifically in deck
        shuffledDeck.splice(shuffledDeck.end(), Deck.cards, it);
    }

    // Assign the shuffled deck back to the original deck
    Deck.cards = move(shuffledDeck);
}

// Draws a card from the deck and returns it
bool drawCard(deck& Deck, card& drawnCard) {
    if (!Deck.cards.empty()) {
        // NNON-mutating algorithm: find if the card has already been dealt
        auto it = Deck.cards.begin();
        while (it != Deck.cards.end()) {
            pair<Suit, Rank> cardPair = make_pair(it->suit, it->rank);
            if (dealtCards.find(cardPair) == dealtCards.end()) {
                // Card has not been dealt yet
                drawnCard = *it;
                dealtCards.insert(cardPair); // Add to dealt cards set
                Deck.cards.erase(it);
                return true;
            }
            ++it;
        }
        cout << "No more cards to draw!\n";
        return false;
    } else {
        cout << "The deck is empty!\n";
        return false;
    }
}

// Displays the player's hand and calculates the total
void displayPlayerHand(queue<card> playerHand, int& total) {
    total = 0;
    list<int> cardValuesList;

    // Collect card values using transform (Mutating Algorithm)
    while (!playerHand.empty()) {
        card currentCard = playerHand.front();
        printCard(currentCard);
        cardValuesList.push_back(cardValues[currentCard.rank]);
        playerHand.pop();
    }

    // Adjust for aces(i hate aces so much, 4 hours bug fixing for nothing because i forgot aces were a thing)
    total = accumulate(cardValuesList.begin(), cardValuesList.end(), 0);
    int aceCount = count(cardValuesList.begin(), cardValuesList.end(), 11);

    while (aceCount > 0 && total > 21) {
        total -= 10;
        aceCount--;
    }

    cout << "Total: " << total << endl;
}

// Displays the dealer's hand and calculates the total(not working* come back later after implementing the hand changes)
void displayDealerHand(stack<card> dealerHand, int& total) {
    total = 0;
    list<int> cardValuesList;

    // Collect card values
    stack<card> tempStack;
    while (!dealerHand.empty()) {
        card currentCard = dealerHand.top();
        printCard(currentCard);
        cardValuesList.push_back(cardValues[currentCard.rank]);
        tempStack.push(currentCard);
        dealerHand.pop();
    }

    // Restore the dealer's hand
    while (!tempStack.empty()) {
        dealerHand.push(tempStack.top());
        tempStack.pop();
    }

    // Adjust for aces
    total = accumulate(cardValuesList.begin(), cardValuesList.end(), 0);
    int aceCount = count(cardValuesList.begin(), cardValuesList.end(), 11);

    while (aceCount > 0 && total > 21) {
        total -= 10;
        aceCount--;
    }

    cout << "Total: " << total << endl;
}

// Calculate total for queue (player's hand)
void calculateTotal(queue<card> hand, int& total) {
    total = 0;
    list<int> cardValuesList;

    while (!hand.empty()) {
        card currentCard = hand.front();
        cardValuesList.push_back(cardValues[currentCard.rank]);
        hand.pop();
    }

    total = accumulate(cardValuesList.begin(), cardValuesList.end(), 0);
}

// Calculate total for stack (dealer's hand)
void calculateTotal(stack<card> hand, int& total) {
    total = 0;
    list<int> cardValuesList;
    stack<card> tempStack;

    while (!hand.empty()) {
        card currentCard = hand.top();
        cardValuesList.push_back(cardValues[currentCard.rank]);
        tempStack.push(currentCard);
        hand.pop();
    }

    // Restore the hand
    while (!tempStack.empty()) {
        hand.push(tempStack.top());
        tempStack.pop();
    }

    total = accumulate(cardValuesList.begin(), cardValuesList.end(), 0);
}

